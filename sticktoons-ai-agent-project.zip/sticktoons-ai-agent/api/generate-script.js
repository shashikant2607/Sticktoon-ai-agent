import OpenAI from "openai";
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST." });
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "OPENAI_API_KEY is missing from Vercel settings." });
  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    const topic = String(body.topic || "a surprising fact about AI or technology").slice(0, 200);
    const tone = String(body.tone || "curious and punchy").slice(0, 80);
    const c = await client.chat.completions.create({
      model: "gpt-4o-mini", temperature: 0.8,
      messages: [
        { role: "system", content: "Write original, accurate English YouTube Shorts for a general US audience, 35-50 seconds. Strong hook, simple spoken English, no unsupported claims. Return TITLE, VOICEOVER, ON-SCREEN TEXT (5 beats), DESCRIPTION, HASHTAGS." },
        { role: "user", content: "Topic: " + topic + "\\nStyle: " + tone }
      ]
    });
    return res.status(200).json({ script: c.choices?.[0]?.message?.content || "No script returned." });
  } catch (e) { return res.status(500).json({ error: "Script generation failed; check API key and usage limits.", detail: String(e.message || e).slice(0, 350) }); }
}