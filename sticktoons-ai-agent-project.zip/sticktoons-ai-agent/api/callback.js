import { google } from "googleapis";
export default async function handler(req, res) {
  const { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI } = process.env;
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !GOOGLE_REDIRECT_URI) return res.status(500).send("OAuth is not configured.");
  if (req.query.error) return res.status(400).send("Google authorization was cancelled or denied.");
  if (!req.query.code) return res.status(400).send("Missing OAuth authorization code.");
  try {
    const oauth = new google.auth.OAuth2(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI);
    const { tokens } = await oauth.getToken(String(req.query.code));
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    if (tokens.refresh_token) return res.status(200).send("Authorization succeeded. Copy this refresh token directly into Vercel Environment Variables as YOUTUBE_REFRESH_TOKEN, then redeploy. Do not share it.\\n\\nYOUTUBE_REFRESH_TOKEN=" + tokens.refresh_token);
    return res.status(200).send("Authorized, but Google returned no refresh token. Remove app permissions in your Google Account and retry /api/auth.");
  } catch (e) { return res.status(500).send("OAuth failed. Check client type and exact redirect URI. " + String(e.message || e)); }
}