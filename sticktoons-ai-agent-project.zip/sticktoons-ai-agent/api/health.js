export default function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  res.status(200).json({
    ok: true,
    message: "Sticktoons AI Studio is running",
    configured: {
      openai: Boolean(process.env.OPENAI_API_KEY),
      googleOAuth: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET && process.env.GOOGLE_REDIRECT_URI),
      youtubeRefreshToken: Boolean(process.env.YOUTUBE_REFRESH_TOKEN)
    },
    note: "Starter workflow only; automatic video rendering is not configured."
  });
}