import { google } from "googleapis";
import { Readable } from "node:stream";
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST." });
  const { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI, YOUTUBE_REFRESH_TOKEN } = process.env;
  if (![GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI, YOUTUBE_REFRESH_TOKEN].every(Boolean))
    return res.status(503).json({ error: "YouTube OAuth is not fully configured in Vercel." });
  try {
    const b = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    const u = new URL(String(b.videoUrl || ""));
    if (u.protocol !== "https:") return res.status(400).json({ error: "videoUrl must be HTTPS." });
    if (!String(b.title || "").trim()) return res.status(400).json({ error: "A video title is required." });
    const v = await fetch(u, { redirect: "error" });
    if (!v.ok || !v.body) return res.status(400).json({ error: "Could not download MP4 from the URL." });
    const type = v.headers.get("content-type") || "video/mp4";
    const auth = new google.auth.OAuth2(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI);
    auth.setCredentials({ refresh_token: YOUTUBE_REFRESH_TOKEN });
    const yt = google.youtube({ version: "v3", auth });
    const result = await yt.videos.insert({
      part: ["snippet", "status"],
      requestBody: {
        snippet: { title: String(b.title).slice(0,100), description: String(b.description || "").slice(0,5000), categoryId: "28", tags: ["AI","Technology","Shorts"] },
        status: { privacyStatus: ["private","unlisted","public"].includes(b.privacyStatus) ? b.privacyStatus : "private", selfDeclaredMadeForKids: false }
      },
      media: { body: Readable.fromWeb(v.body), mimeType: type }
    });
    return res.status(200).json({ ok: true, videoId: result.data.id, privacyStatus: b.privacyStatus || "private" });
  } catch (e) { return res.status(500).json({ error: "Upload failed; check OAuth, video URL, quota and Vercel limits.", detail: String(e.message || e).slice(0,400) }); }
}